
import React, { useState, useEffect } from 'react';
import { Page, StylingResult, UserInput } from './types';
import Navigation from './components/Navigation';
import HomePage from './pages/HomePage';
import FeaturesPage from './pages/FeaturesPage';
import TryItPage from './pages/TryItPage';
import ResultsPage from './pages/ResultsPage';
import ShoppingPage from './pages/ShoppingPage';
import { analyzeStyle } from './services/geminiService';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [userInput, setUserInput] = useState<UserInput>({ gender: 'female', image: null });
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<StylingResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleStartAnalysis = async (input: UserInput) => {
    setUserInput(input);
    setIsAnalyzing(true);
    setCurrentPage('results');
    setError(null);

    try {
      const analysis = await analyzeStyle(input);
      setResult(analysis);
    } catch (err) {
      console.error(err);
      setError("Failed to analyze style. Please try again with a clearer photo.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onStart={() => setCurrentPage('try-it')} />;
      case 'features':
        return <FeaturesPage />;
      case 'try-it':
        return <TryItPage onSubmit={handleStartAnalysis} />;
      case 'results':
        return (
          <ResultsPage 
            result={result} 
            loading={isAnalyzing} 
            error={error} 
            onShop={() => setCurrentPage('shopping')}
            onRetry={() => setCurrentPage('try-it')}
          />
        );
      case 'shopping':
        return <ShoppingPage products={result?.products || []} />;
      case 'about':
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-white p-8">
            <h1 className="text-4xl font-bold mb-4">About StylerAI</h1>
            <p className="max-w-2xl text-center text-lg bg-white/10 p-8 rounded-3xl glass">
              StylerAI is your cutting-edge fashion companion. Built with advanced AI technology, 
              we help you discover the styles that truly reflect your personality and enhance your 
              natural features. From color theory to personalized shopping lists, we've got you covered.
            </p>
          </div>
        );
      default:
        return <HomePage onStart={() => setCurrentPage('try-it')} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-400 via-purple-500 to-orange-400">
      <Navigation currentPage={currentPage} onPageChange={setCurrentPage} />
      <main className="container mx-auto px-4 py-8 md:py-12">
        {renderPage()}
      </main>
      
      {/* Background blobs for flair */}
      <div className="fixed -bottom-24 -left-24 w-96 h-96 bg-yellow-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 pointer-events-none"></div>
      <div className="fixed -top-24 -right-24 w-96 h-96 bg-pink-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 pointer-events-none"></div>
    </div>
  );
};

export default App;
