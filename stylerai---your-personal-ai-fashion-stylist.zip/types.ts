
export interface Product {
  id: string;
  name: string;
  price: string;
  image: string;
  link: string;
  description: string;
}

export interface StylingResult {
  skinTone: string;
  currentStyle: string;
  outfitRecommendations: string[];
  colorSuggestions: string[];
  stylingTips: string[];
  products: Product[];
}

export type Page = 'home' | 'features' | 'try-it' | 'results' | 'shopping' | 'about';

export interface UserInput {
  gender: 'male' | 'female' | 'other';
  image: string | null;
}
