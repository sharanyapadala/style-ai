
import React from 'react';
import { StylingResult } from '../types';
import GlassCard from '../components/GlassCard';

interface ResultsPageProps {
  result: StylingResult | null;
  loading: boolean;
  error: string | null;
  onShop: () => void;
  onRetry: () => void;
}

const ResultsPage: React.FC<ResultsPageProps> = ({ result, loading, error, onShop, onRetry }) => {
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
        <div className="relative">
          <div className="w-24 h-24 border-8 border-white/20 border-t-white rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center text-2xl">👗</div>
        </div>
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold text-white">Analyzing your style...</h2>
          <p className="text-white/70 animate-pulse">Our AI is curating your perfect look</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-2xl mx-auto py-12">
        <GlassCard className="text-center space-y-6">
          <div className="text-6xl">⚠️</div>
          <h2 className="text-3xl font-bold text-white">Oops!</h2>
          <p className="text-white/80">{error}</p>
          <button 
            onClick={onRetry}
            className="bg-white text-purple-600 px-8 py-3 rounded-full font-bold shadow-lg"
          >
            Try Another Photo
          </button>
        </GlassCard>
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="space-y-12 py-12 animate-in fade-in zoom-in duration-700">
      <div className="text-center space-y-4">
        <h2 className="text-4xl md:text-5xl font-bold text-white">Your Style Identity</h2>
        <p className="text-white/80">Based on your unique features and color palette</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Breakdown */}
        <GlassCard className="md:col-span-1 space-y-8">
          <div>
            <h3 className="text-xs uppercase tracking-widest text-white/50 font-bold mb-2">Detected Skin Tone</h3>
            <p className="text-2xl font-bold text-white">{result.skinTone}</p>
          </div>
          <div>
            <h3 className="text-xs uppercase tracking-widest text-white/50 font-bold mb-2">Recommended Palette</h3>
            <div className="flex flex-wrap gap-2">
              {result.colorSuggestions.map((color, i) => (
                <div 
                  key={i} 
                  className="px-4 py-2 rounded-xl bg-white/10 text-white text-sm font-medium border border-white/20"
                >
                  {color}
                </div>
              ))}
            </div>
          </div>
          <div className="pt-4">
             <button 
              onClick={onShop}
              className="w-full bg-white text-purple-600 py-4 rounded-2xl font-bold btn-glow transition-all"
            >
              Shop the Look 🛍️
            </button>
          </div>
        </GlassCard>

        {/* Recommendations */}
        <div className="md:col-span-2 space-y-8">
          <GlassCard>
            <h3 className="text-xl font-bold text-white mb-6 flex items-center">
              <span className="mr-3">👔</span> Recommended Outfits
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {result.outfitRecommendations.map((rec, i) => (
                <div key={i} className="p-4 bg-white/5 rounded-2xl border border-white/10 text-white/90">
                  {rec}
                </div>
              ))}
            </div>
          </GlassCard>

          <GlassCard>
            <h3 className="text-xl font-bold text-white mb-6 flex items-center">
              <span className="mr-3">💡</span> Professional Styling Tips
            </h3>
            <ul className="space-y-4">
              {result.stylingTips.map((tip, i) => (
                <li key={i} className="flex items-start text-white/80 leading-relaxed">
                  <span className="text-pink-300 mr-3 mt-1">•</span>
                  {tip}
                </li>
              ))}
            </ul>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;
