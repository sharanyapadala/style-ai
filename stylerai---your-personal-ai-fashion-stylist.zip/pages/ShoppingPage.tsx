
import React from 'react';
import { Product } from '../types';
import GlassCard from '../components/GlassCard';

interface ShoppingPageProps {
  products: Product[];
}

const ShoppingPage: React.FC<ShoppingPageProps> = ({ products }) => {
  return (
    <div className="py-12 space-y-12">
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-white">Curated For You</h2>
        <p className="text-white/70">Shop items that match your AI analysis</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {products.map((product) => (
          <GlassCard key={product.id} className="flex flex-col h-full group">
            <div className="relative overflow-hidden rounded-2xl mb-4 aspect-[3/4]">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute top-3 right-3 bg-white/90 px-3 py-1 rounded-full text-purple-600 font-bold text-sm shadow-lg">
                {product.price}
              </div>
            </div>
            <h3 className="text-white font-bold text-lg mb-2">{product.name}</h3>
            <p className="text-white/60 text-sm mb-6 flex-grow">{product.description}</p>
            <button className="w-full bg-white text-purple-600 py-3 rounded-xl font-bold shadow-lg hover:shadow-2xl transition-all duration-300 active:scale-95">
              Shop Now
            </button>
          </GlassCard>
        ))}
      </div>
      
      {products.length === 0 && (
        <div className="text-center py-24">
          <p className="text-white/50 text-xl italic">Upload a photo to see personalized shopping recommendations.</p>
        </div>
      )}
    </div>
  );
};

export default ShoppingPage;
