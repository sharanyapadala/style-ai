
import React from 'react';
import GlassCard from '../components/GlassCard';

const FeaturesPage: React.FC = () => {
  const features = [
    {
      title: "Instant Analysis",
      desc: "Our AI scans your photo to identify your unique features and existing style patterns instantly.",
      icon: "⚡",
      color: "bg-blue-500"
    },
    {
      title: "Color Matching",
      desc: "Get scientific color palettes that complement your skin tone and make your eyes pop.",
      icon: "🎨",
      color: "bg-pink-500"
    },
    {
      title: "Product Links",
      desc: "Direct access to shoppable items that match your recommendations perfectly.",
      icon: "🔗",
      color: "bg-purple-500"
    },
    {
      title: "Professional Tips",
      desc: "Expert styling advice tailored to your body type and the occasion you're dressing for.",
      icon: "👗",
      color: "bg-orange-500"
    }
  ];

  return (
    <div className="py-12">
      <div className="text-center mb-16 space-y-4">
        <h2 className="text-4xl md:text-5xl font-bold text-white">Smart Fashion Tools</h2>
        <p className="text-white/80 max-w-2xl mx-auto">Discover how StylerAI transforms your wardrobe using cutting-edge vision technology.</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {features.map((feature, i) => (
          <GlassCard key={i} className="flex flex-col items-center text-center p-8">
            <div className={`w-16 h-16 ${feature.color} rounded-2xl flex items-center justify-center text-3xl shadow-lg mb-6`}>
              {feature.icon}
            </div>
            <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
            <p className="text-white/70 leading-relaxed">{feature.desc}</p>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};

export default FeaturesPage;
