
import React, { useState, useRef } from 'react';
import { UserInput } from '../types';
import GlassCard from '../components/GlassCard';

interface TryItPageProps {
  onSubmit: (input: UserInput) => void;
}

const TryItPage: React.FC<TryItPageProps> = ({ onSubmit }) => {
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('female');
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (imagePreview) {
      onSubmit({ gender, image: imagePreview });
    } else {
      alert("Please upload an image first!");
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12">
      <GlassCard className="p-8 md:p-12">
        <h2 className="text-3xl font-bold text-white mb-8 text-center">Step into the Future of Fashion</h2>
        
        <form onSubmit={handleSubmit} className="space-y-12">
          {/* Gender Selection */}
          <div className="space-y-4">
            <label className="text-white font-medium block text-center mb-4">Select Gender Preference</label>
            <div className="flex justify-center space-x-4">
              {['male', 'female', 'other'].map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g as any)}
                  className={`px-8 py-3 rounded-2xl capitalize transition-all duration-300 font-bold ${
                    gender === g 
                    ? 'bg-white text-purple-600 shadow-xl scale-105' 
                    : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Image Upload Area */}
          <div className="space-y-4">
            <label className="text-white font-medium block text-center mb-4">Upload Your Photo</label>
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`border-4 border-dashed border-white/30 rounded-3xl p-8 md:p-16 flex flex-col items-center justify-center cursor-pointer transition-all duration-300 hover:border-white/60 hover:bg-white/5 ${
                imagePreview ? 'border-none p-0 overflow-hidden relative' : ''
              }`}
            >
              {imagePreview ? (
                <>
                  <img src={imagePreview} alt="Preview" className="w-full max-h-[400px] object-cover rounded-2xl" />
                  <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 flex items-center justify-center transition-opacity duration-300">
                    <span className="text-white font-bold bg-white/20 backdrop-blur-md px-6 py-3 rounded-full">Change Image</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="w-20 h-20 bg-white/10 rounded-full flex items-center justify-center mb-6 text-4xl">
                    📸
                  </div>
                  <p className="text-white text-lg font-medium">Click to browse or drag and drop</p>
                  <p className="text-white/50 text-sm mt-2">Supports JPG, PNG, WEBP (Max 5MB)</p>
                </>
              )}
            </div>
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageChange} 
              className="hidden" 
              accept="image/*"
            />
          </div>

          <div className="flex justify-center pt-6">
            <button
              type="submit"
              disabled={!imagePreview}
              className={`w-full md:w-auto px-12 py-5 rounded-full text-xl font-bold transition-all duration-300 shadow-2xl ${
                imagePreview 
                ? 'bg-white text-purple-600 btn-glow hover:scale-105' 
                : 'bg-white/20 text-white/40 cursor-not-allowed'
              }`}
            >
              Analyze My Style ✨
            </button>
          </div>
        </form>
      </GlassCard>
    </div>
  );
};

export default TryItPage;
