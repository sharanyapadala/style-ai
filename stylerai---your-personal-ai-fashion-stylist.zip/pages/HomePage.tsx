
import React from 'react';

interface HomePageProps {
  onStart: () => void;
}

const HomePage: React.FC<HomePageProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col md:flex-row items-center justify-between py-12 md:py-24">
      <div className="md:w-1/2 text-white space-y-6 text-center md:text-left">
        <h1 className="text-5xl md:text-7xl font-extrabold leading-tight tracking-tight">
          Your Personal <span className="text-pink-300 block">AI Fashion</span> Stylist
        </h1>
        <p className="text-xl md:text-2xl text-white/90 max-w-xl mx-auto md:mx-0 font-light">
          Upload a photo, and let our advanced AI curate the perfect look for your body type, skin tone, and personality.
        </p>
        <div className="pt-8">
          <button
            onClick={onStart}
            className="bg-white text-purple-600 px-10 py-5 rounded-full text-xl font-bold btn-glow transition-all duration-300 hover:scale-105 active:scale-95 shadow-2xl"
          >
            Get Started Free
          </button>
        </div>
        <div className="flex items-center justify-center md:justify-start space-x-6 pt-8 text-white/70">
          <div className="text-center">
            <div className="text-3xl font-bold text-white">10k+</div>
            <div className="text-xs">Outfits Styled</div>
          </div>
          <div className="w-px h-10 bg-white/20"></div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white">99%</div>
            <div className="text-xs">Happy Users</div>
          </div>
        </div>
      </div>

      <div className="md:w-1/2 mt-16 md:mt-0 flex justify-center relative">
        <div className="absolute inset-0 bg-white/20 rounded-full filter blur-3xl scale-125 animate-pulse"></div>
        <img 
          src="https://picsum.photos/id/64/600/800" 
          alt="Fashion Model" 
          className="relative w-72 md:w-96 rounded-3xl shadow-2xl border-4 border-white/30 object-cover animate-float"
        />
        <div className="absolute -bottom-6 -right-6 glass p-6 rounded-2xl shadow-xl hidden md:block border border-white/50">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-pink-500 rounded-full flex items-center justify-center">
              <span className="text-white text-lg">✨</span>
            </div>
            <div>
              <div className="text-white font-bold text-sm">Perfect Match!</div>
              <div className="text-white/70 text-xs">Summer Palette</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
