
import React, { useState } from 'react';
import { Page } from '../types';

interface NavigationProps {
  currentPage: Page;
  onPageChange: (page: Page) => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentPage, onPageChange }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems: { label: string; value: Page }[] = [
    { label: 'Home', value: 'home' },
    { label: 'Features', value: 'features' },
    { label: 'Try It', value: 'try-it' },
    { label: 'About', value: 'about' },
  ];

  return (
    <nav className="sticky top-0 z-50 px-4 py-4 md:px-8">
      <div className="glass max-w-7xl mx-auto rounded-2xl md:rounded-full px-6 py-3 flex items-center justify-between">
        <div 
          className="text-2xl font-bold text-white cursor-pointer hover:scale-105 transition-transform"
          onClick={() => onPageChange('home')}
        >
          Styler<span className="text-pink-300">AI</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item.value}
              onClick={() => onPageChange(item.value)}
              className={`text-sm font-medium transition-all duration-300 hover:text-pink-200 ${
                currentPage === item.value ? 'text-white border-b-2 border-white' : 'text-white/80'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button 
            onClick={() => onPageChange('try-it')}
            className="bg-white text-purple-600 px-6 py-2 rounded-full font-bold text-sm hover:bg-pink-100 transition-all duration-300 shadow-lg hover:shadow-xl active:scale-95"
          >
            Get Started
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden text-white p-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {isOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="md:hidden absolute top-20 left-4 right-4 glass rounded-3xl p-6 space-y-4 shadow-2xl animate-in slide-in-from-top-4 duration-300">
          {navItems.map((item) => (
            <button
              key={item.value}
              onClick={() => {
                onPageChange(item.value);
                setIsOpen(false);
              }}
              className="block w-full text-left text-white text-lg font-medium p-2 border-b border-white/10"
            >
              {item.label}
            </button>
          ))}
          <button 
            onClick={() => {
              onPageChange('try-it');
              setIsOpen(false);
            }}
            className="w-full bg-white text-purple-600 py-3 rounded-2xl font-bold shadow-lg"
          >
            Get Started
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navigation;
