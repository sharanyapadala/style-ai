
import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  animate?: boolean;
}

const GlassCard: React.FC<GlassCardProps> = ({ children, className = '', animate = true }) => {
  return (
    <div className={`glass rounded-3xl p-6 transition-all duration-500 ${
      animate ? 'hover:-translate-y-2 hover:shadow-2xl' : ''
    } ${className}`}>
      {children}
    </div>
  );
};

export default GlassCard;
